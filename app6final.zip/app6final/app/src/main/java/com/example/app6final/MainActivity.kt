package com.example.app6final

import android.content.pm.ActivityInfo
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.ImageView
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_main.view.*

class MainActivity : AppCompatActivity() {

    var enemyImg: ImageView? = null
    private var start = false
    private var zoom_counter = 0
    private var imageView: ImageView? = null
    private var fadeOutCompleteViewComplete = false
    private var fadeOutMyViewComplete = false
    private var repeatCount = 0


    companion object {
        private var instance: MainActivity? = null

        public fun getInstance(): MainActivity {
            return instance!!
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        instance = this
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        var myZoom = AnimationUtils.loadAnimation(MainActivity.getInstance(), R.anim.zoom_in)
        var zoomHandler = ZoomHandler()
        myZoom.setAnimationListener(zoomHandler)
        titleView.startAnimation(myZoom)
    }

    fun showEnemy(type : Int)
    {
        println("$type")
        var xscale = -1
        var playerAnimal = MyView.getInstance().pick
        var winner = MyView.getInstance().result
        if (type == 0)
        {
            enemy0?.setImageResource(R.drawable.lion0)
        }
        else if(type == 2)
        {
            enemy0?.setImageResource(R.drawable.rabbit)
            xscale = 1
        }

        else if(type == 1)
        {
            enemy0?.setImageResource(R.drawable.cobra)
        }

        enemy0?.scaleX = xscale.toFloat()

        if(!start)
        {
            start = !start
        }
        var myFadeIn = AnimationUtils.loadAnimation(MainActivity.getInstance(), R.anim.fade_in)
        var animHandler1 = FadeInHandler()
        myFadeIn.setAnimationListener(animHandler1)
        enemy0?.startAnimation(myFadeIn)
    }

    inner class FadeOutHandler : Animation.AnimationListener {
        override fun onAnimationRepeat(animation: Animation?) {
            println("repeat")
        }
        override fun onAnimationStart(animation: Animation?)
        {
        }
        override fun onAnimationEnd(animation: Animation?)
        {
        }

    }

    inner class FadeInHandler : Animation.AnimationListener {

        override fun onAnimationStart(animation: Animation?)
        {
        }
        override fun onAnimationRepeat(animation: Animation?)
        {
            println("repeat")
        }

        override fun onAnimationEnd(animation: Animation?)
        {
        }
    }

    inner class DissolveHandler : Animation.AnimationListener {
        override fun onAnimationStart(animation: Animation?)
        {
            if (!start) {
                start = true
            }
            var myFadeIn = AnimationUtils.loadAnimation(MainActivity.getInstance(), R.anim.fade_in)
            var animHandler2 = FadeInHandler()
            myFadeIn.setAnimationListener(animHandler2)
            imageView?.startAnimation(myFadeIn)
        }

        override fun onAnimationRepeat(animation: Animation?)
        {
            println("repeat")
        }

        override fun onAnimationEnd(animation: Animation?)
        {
            if (start) {
                var myFadeIn = AnimationUtils.loadAnimation(MainActivity.getInstance(), R.anim.fade_in)
                var animHandler2 = FadeInHandler()
                myFadeIn.setAnimationListener(animHandler2)
                phoneText.startAnimation(myFadeIn)
                cpuScore.startAnimation(myFadeIn)
                playerText.startAnimation(myFadeIn)
                playerScore.startAnimation(myFadeIn)
            }
        }
    }

    inner class ZoomHandler : Animation.AnimationListener {
        override fun onAnimationStart(animation: Animation?)
        {
        }

        override fun onAnimationRepeat(animation: Animation?) {
            println("repeat")
        }

        override fun onAnimationEnd(animation: Animation?)
        {
            if (!start)
            {
                var myFadeOut = AnimationUtils.loadAnimation(MainActivity.getInstance(), R.anim.fade_out)
                var animHandler1 = DissolveHandler()
                myFadeOut.setAnimationListener(animHandler1)
                titleView.startAnimation(myFadeOut)
                start = true
            }
        }

    }

}

