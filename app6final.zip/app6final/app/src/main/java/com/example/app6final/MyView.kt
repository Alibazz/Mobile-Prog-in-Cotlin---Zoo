package com.example.app6final

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.animation.AlphaAnimation
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.view.animation.TranslateAnimation
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.constraintlayout.widget.ConstraintLayout
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_main.view.*

class MyView : View {
    var lionFade : Boolean = false
    var cobraFade : Boolean = false
    var rabbitFade : Boolean = false
    var enemyFade : Boolean = false
    private var lionStartCoords: Rect = Rect(0, 0, 0, 0)
    private var cobraStartCoords: Rect = Rect(0, 0, 0, 0)
    private var rabbitStartCoords: Rect = Rect(0, 0, 0, 0)
    private var circleCoords: RectF = RectF(0.0f, 0.0f, 0.0f, 0.0f)
    private var animalCoords: Rect = Rect(0, 0, 0, 0)
    private var lionCoords: Rect = Rect(0, 0, 0, 0)
    private var cobraCoords: Rect = Rect(0, 0, 0, 0)
    private var rabbitCoords: Rect = Rect(0, 0, 0, 0)
    var phoneScore : Boolean = false
    var userScore : Boolean = false
    private var imageView : ImageView? = null
    private var fadeOutMyViewComplete = false
    private var fadeOutCompleteViewComplete = false
    private var repeatCount = 0
    var resetLion : Boolean = false
    var resetCobra : Boolean = false
    var resetRabbit : Boolean = false
    private var offsetLion: Point = Point(0, 0)
    private var offsetCobra: Point = Point(0, 0)
    private var offsetRabbit: Point = Point(0, 0)
    private var lionTouch = false
    private var cobraTouch = false
    private var rabbitTouch = false
    var rnd = (0..2).random()
    var pick = 3
    private var zoom_counter = 0
    var xscale = -1
    var count = 16
    private var start: Boolean = true
    private var width1: Int = 0
    private var height1: Int = 0
    private var animal_touched = false
    private var firstTouch = false
    private var prevTime = 0L
    var paint = Paint()

    companion object
    {
        private var instance: MyView? = null
        public fun getInstance(): MyView
        {
            return instance!!
        }
    }

    public fun setanimalCoords(ux: Int, uy: Int, lx: Int, ly: Int)
    {
        this.animalCoords.set(ux, uy, lx, ly)
    }
    public fun getanimalCoords(): Rect
    {
        return animalCoords
    }
    public fun setCircleCoords(ux: Float, uy: Float, lx: Float, ly: Float)
    {
        this.circleCoords.set(ux, uy, lx, ly)
    }
    constructor(context: Context, attrs: AttributeSet) : super(context, attrs)
    {
        this.setWillNotDraw(false)
        instance = this
    }


    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        var height = getHeight()
        var width = getWidth()
        var lion = MainActivity.getInstance().lion
        var cobra = MainActivity.getInstance().cobra
        var rabbit = MainActivity.getInstance().rabbit

        if (start)
        {
            start = false
        }
        else
        {
            lion.setX(lionCoords.left.toFloat())
            lion.setY(lionCoords.top.toFloat())
            cobra.setX(cobraCoords.left.toFloat())
            cobra.setY(cobraCoords.top.toFloat())
            rabbit.setX(rabbitCoords.left.toFloat())
            rabbit.setY(rabbitCoords.top.toFloat())
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean
    {

        var currentTime = System.currentTimeMillis()
        var lion = MainActivity.getInstance().lion
        var rabbit = MainActivity.getInstance().rabbit
        var cobra = MainActivity.getInstance().cobra
        var cover = MainActivity.getInstance().cover
        lionCoords = Rect(lion.left,lion.top,lion.right,lion.bottom)
        cobraCoords = Rect(cobra.left,cobra.top,cobra.right,cobra.bottom)
        rabbitCoords = Rect(rabbit.left,rabbit.top,rabbit.right,rabbit.bottom)
        var x = (event.getX())
        var y = (event.getY())

        if (event.getAction() == MotionEvent.ACTION_DOWN )
        {
            println("$x, $y")
            if ( (x > lion.left) && (x < lion.right) &&
                (y > lion.top) && (y < lion.bottom))
            {
                lionStartCoords = Rect(rabbit.left,lion.top,rabbit.right,lion.bottom)
                lionCoords = Rect(rabbit.left,lion.top,rabbit.right,lion.bottom)
                println("Lion")
                animal_touched = true
                lionTouch = true
            }
            else
                if ( (x > cobra.left) && (x < cobra.right) &&
                (y > cobra.top) && (y < cobra.bottom))
            {
                cobraStartCoords = Rect(cobra.left,cobra.top,cobra.right,cobra.bottom)
                cobraCoords = Rect(cobra.left,cobra.top,cobra.right,cobra.bottom)
                println("Cobra")
                animal_touched = true
                cobraTouch = true
            }
            else
                if ( (x > rabbit.left) && (x < rabbit.right) &&
                (y > rabbit.top) && (y < rabbit.bottom))
            {
                rabbitStartCoords = Rect(rabbit.left,rabbit.top,rabbit.right,rabbit.bottom)
                rabbitCoords = Rect(rabbit.left,rabbit.top,rabbit.right,rabbit.bottom)
                println("Rabbit")
                animal_touched = true
                rabbitTouch = true
            }
        }
        else if (event.getAction() ==  MotionEvent.ACTION_MOVE)
        {
            if(lionTouch) {

                if (count > 40)
                {
                    count = 0
                }
                var fn = "lion" + (count/10).toInt()
                var id = MainActivity.getInstance().resources.getIdentifier(fn, "drawable", MainActivity.getInstance().packageName)
                lion.setImageResource(id)
                count++

                lionCoords.left = x.toInt()-(lion.width/2)
                lionCoords.right = x.toInt()+(lion.width/2)
                lionCoords.top = y.toInt()-(lion.height/2)
                lionCoords.bottom = y.toInt()+(lion.height/2)
                this.invalidate()
            }
            else if(cobraTouch){
                cobraCoords.left = x.toInt() - 100
                cobraCoords.right = x.toInt() + 50
                cobraCoords.top = y.toInt() - 100
                cobraCoords.bottom = y.toInt()+50
                this.invalidate()
            }
            else if(rabbitTouch)
            {
                rabbitCoords.left = x.toInt() - 100
                rabbitCoords.right = (x + rabbit.getWidth() - offsetRabbit.x).toInt()
                rabbitCoords.top = y.toInt() - 200
                rabbitCoords.bottom = y.toInt() + 50
                this.invalidate()

            }
        }
        else if (event.getAction() == MotionEvent.ACTION_UP)
        {
            rnd = (0..2).random()
            if(lionTouch){
                lionCoords.left = (x - (lion.width/2)).toInt()
                lionCoords.right = (x + (lion.width/2)).toInt()
                lionCoords.top = y.toInt() - (lion.width/2)
                lionCoords.bottom = y.toInt() + (lion.width/2)
            }
            else if(cobraTouch){
                cobraCoords.left = (x - (cobra.width/2)).toInt()
                cobraCoords.top = y.toInt()- (cobra.height/2)
                cobraCoords.right = (x + (cobra.width/2)).toInt()
                cobraCoords.bottom = y.toInt()+ (cobra.height/2)
            }
            else if(rabbitTouch){
                rabbitCoords.left = (x - (rabbit.width/2)).toInt()
                rabbitCoords.top = (y - (rabbit.height/2)).toInt()
                rabbitCoords.right = (x + (rabbit.width/2)).toInt()
                rabbitCoords.bottom = (y + (rabbit.height/2)).toInt()
            }
            if ( ((lionCoords.left > cover.left) && (lionCoords.right < cover.right) &&
                        (lionCoords.top > cover.top) && (lionCoords.bottom < cover.bottom)) ||(
                        (cobraCoords.left > cover.left) && (cobraCoords.right < cover.right) &&
                                (cobraCoords.top > cover.top) && (cobraCoords.bottom < cover.bottom)) ||
                ((rabbitCoords.left > cover.left) && (rabbitCoords.right < cover.right) &&
                        (rabbitCoords.top > cover.top) && (rabbitCoords.bottom < cover.bottom))){

                if(lionTouch){
                    pick = 0
                    lionCoords.left = cover.right - lion.width
                    lionCoords.top = (height*.45).toInt()
                    lionCoords.right = cover.right
                    lionCoords.bottom = lionCoords.top + lion.height
                    MainActivity.getInstance().showEnemy(rnd)
                    battle(rnd, pick)
                    lionTouch = false
                }
                else if(cobraTouch){
                    pick = 1
                    cobraCoords.left = cover.right - cobra.width
                    cobraCoords.top = (height*.45).toInt()
                    cobraCoords.right = cover.right
                    cobraCoords.bottom = cobraCoords.top + cobra.height
                    this.invalidate()
                    MainActivity.getInstance().showEnemy(rnd)
                    battle(rnd, pick)
                    cobraTouch = false
                }
                else if(rabbitTouch){
                    pick = 2
                    rabbitCoords.left = cover.right - rabbit.width
                    rabbitCoords.top = (height*.45).toInt()
                    rabbitCoords.right = cover.right
                    rabbitCoords.bottom = rabbitCoords.top + rabbit.height
                    this.invalidate()
                    MainActivity.getInstance().showEnemy(rnd)
                    battle(rnd, pick)
                    rabbitTouch = false
                }

            }
            else if(lionTouch)
            {
                lionCoords = lionStartCoords
                lion.setImageResource(R.drawable.lion0)

                lionTouch = false
            }else if(cobraTouch) {
                cobraCoords = cobraStartCoords
                cobraTouch = false
            }else if(rabbitTouch) {
                rabbitCoords = rabbitStartCoords
                rabbitTouch = false
            }

            this.invalidate()
            lionTouch = false
            cobraTouch = false
            rabbitTouch = false
            println("touched up - $x, $y")
        }
        return true
    }


    public fun resetPosition(){

        var lion = MainActivity.getInstance().lion
        var cobra = MainActivity.getInstance().cobra
        var rabbit = MainActivity.getInstance().rabbit
        if(resetLion)
        {
            var myFadeIn = AnimationUtils.loadAnimation(MainActivity.getInstance(), R.anim.fade_in)
            var animHandler2 = FadeInHandler()
            myFadeIn.setAnimationListener(animHandler2)
            lion.setX(lionStartCoords.left.toFloat())
            lion.setY(lionStartCoords.top.toFloat())
            lion.setImageResource(R.drawable.lion0)
            lion.startAnimation(myFadeIn)
            resetLion = false
        }
        else if(resetCobra){
            var myFadeIn = AnimationUtils.loadAnimation(MainActivity.getInstance(), R.anim.fade_in)
            var animHandler2 = FadeInHandler()
            myFadeIn.setAnimationListener(animHandler2)
            cobraCoords = cobraStartCoords
            cobra.setX(cobraStartCoords.left.toFloat())
            cobra.setY(cobraStartCoords.top.toFloat())
            cobra.startAnimation(myFadeIn)
            resetCobra = false
        }
        else if(resetRabbit)
        {
            var myFadeIn = AnimationUtils.loadAnimation(MainActivity.getInstance(), R.anim.fade_in)
            var animHandler2 = FadeInHandler()
            myFadeIn.setAnimationListener(animHandler2)
            rabbitCoords = rabbitStartCoords
            rabbit.setX(rabbitStartCoords.left.toFloat())
            rabbit.setY(rabbitStartCoords.top.toFloat())
            rabbit.startAnimation(myFadeIn)
            resetRabbit = false
        }
    }
    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int)
    {
        super.onSizeChanged(w, h, oldw, oldh)
        var lion = MainActivity.getInstance().lion
        var cobra = MainActivity.getInstance().cobra
        var rabbit = MainActivity.getInstance().rabbit
        lionStartCoords = Rect(lion.left, lion.top, lion.right, lion.bottom)
        cobraStartCoords = Rect(cobra.left, cobra.top, cobra.right, cobra.bottom)
        rabbitStartCoords = Rect(rabbit.left, rabbit.top, rabbit.right, rabbit.bottom)
        offsetLion = Point(lion.width/2,lion.height/2)
        offsetCobra = Point(cobra.width/2,cobra.height/2)
        offsetRabbit = Point(rabbit.width/2,rabbit.height/2)
        rabbit.scaleX = (-1).toFloat()
    }
        fun battle(rnd:Int, user : Int){
        var result = MainActivity.getInstance().result
        var enemy0 = MainActivity.getInstance().enemy0

        var lion = MainActivity.getInstance().lion
        var cobra = MainActivity.getInstance().cobra
        var rabbit = MainActivity.getInstance().rabbit

        var myFadeIn = AnimationUtils.loadAnimation(MainActivity.getInstance(), R.anim.fade_in)
        var animHandler1 = FadeInHandler()
        myFadeIn.setAnimationListener(animHandler1)

        if(rnd == 0 && user == 0){
            var myFadeOut = AnimationUtils.loadAnimation(MainActivity.getInstance(), R.anim.fade_out)
            var animHandler1 = FadeOutHandler()
            myFadeOut.setAnimationListener(animHandler1)
            enemy0?.startAnimation(myFadeOut)
            lion.startAnimation(myFadeOut)
            resetLion = true
            result.setText("Draw!")
        }
        else if(rnd == 1 && user == 1)
        {
            resetCobra = true
            var myFadeOut = AnimationUtils.loadAnimation(MainActivity.getInstance(), R.anim.fade_out)
            var animHandler1 = FadeOutHandler()
            myFadeOut.setAnimationListener(animHandler1)
            enemy0?.startAnimation(myFadeOut)
            cobra.startAnimation(myFadeOut)
            result.setText("Draw!")
        }
        else if(rnd == 2 && user == 2)
        {
            resetRabbit = true
            var myFadeOut = AnimationUtils.loadAnimation(MainActivity.getInstance(), R.anim.fade_out)
            var animHandler1 = FadeOutHandler()
            myFadeOut.setAnimationListener(animHandler1)
            enemy0?.startAnimation(myFadeOut)
            rabbit.startAnimation(myFadeOut)
            result.setText("Draw!")
        }
        else if (rnd == 0 && user == 1){
            resetCobra = true
            var userX =  -418.toFloat()
            var userY =  0f
            var moveAnim = TranslateAnimation(0f, userX, 0f, userY)
            moveAnim.duration = 1000
            moveAnim.fillAfter = true
            var handler = MoveHandler()
            moveAnim.setAnimationListener(handler)
            cobra.startAnimation(moveAnim)
            result.setText("Snake Beats Lion! You Won!")
            userScore = true
        }
        else if (rnd == 0 && user == 2){
            resetRabbit = true
            var userX =  418.toFloat()
            var userY =  0f
            var moveAnim = TranslateAnimation(0f, userX, 0f, userY)
            moveAnim.duration = 1000
            moveAnim.fillAfter = true
            var handler = MoveHandler()
            moveAnim.setAnimationListener(handler)
            enemy0.startAnimation(moveAnim)
            result.setText("Lion Beats Rabbit! You Lost!")
            phoneScore = true
        }
        else if(rnd == 1 && user == 0){
            var userX =  418.toFloat()
            var userY =  0f
            resetLion = true
            var moveAnim = TranslateAnimation(0f, userX, 0f, userY)
            moveAnim.duration = 1000
            moveAnim.fillAfter = true
            var handler = MoveHandler()
            moveAnim.setAnimationListener(handler)
            enemy0.startAnimation(moveAnim)
            result.setText("Snake Beats Lion! You Lost!")
            phoneScore = true
        }
        else if(rnd == 1 && user == 2){
            var userX =  -418.toFloat()
            var userY =  0f
            resetRabbit = true
            var moveAnim = TranslateAnimation(0f, userX, 0f, userY)
            moveAnim.duration = 1000
            moveAnim.fillAfter = true
            var handler = MoveHandler()
            moveAnim.setAnimationListener(handler)
            rabbit.startAnimation(moveAnim)
            result.setText("Rabbit Beats Snake! You Won!")
            userScore = true
        }
        else if(rnd == 2 && user == 0)
        {
            var userX =  -418.toFloat()
            var userY =  0f
            resetLion = true
            var moveAnim = TranslateAnimation(0f, userX, 0f, userY)
            moveAnim.duration = 1000
            moveAnim.fillAfter = true
            var handler = MoveHandler()
            moveAnim.setAnimationListener(handler)
            lion.startAnimation(moveAnim)
            result.setText("Lion Beats Rabbit! You Won!")
            userScore = true

        }
        else if(rnd == 2 && user == 1)
        {
            var userX =  418.toFloat()
            var userY =  0f
            resetCobra = true
            var moveAnim = TranslateAnimation(0f, userX, 0f, userY)
            moveAnim.duration = 1000
            moveAnim.fillAfter = true
            var handler = MoveHandler()
            moveAnim.setAnimationListener(handler)
            enemy0.startAnimation(moveAnim)
            result.setText("Rabbit Beats Snake! You Lost!")
            phoneScore = true
        }
        var cpu = MainActivity.getInstance().cpuScore
        var player = MainActivity.getInstance().playerScore

        if(phoneScore)
        {
            cpu.setText((Integer.parseInt((cpu.text).toString()) + 1).toString())
            phoneScore = false
        }
        else
            if(userScore)
        {
            player.setText((Integer.parseInt((player.text).toString()) + 1).toString())
            userScore = false
        }
        result.startAnimation(myFadeIn)
    }


    inner class FadeOutHandler : Animation.AnimationListener
    {
        override fun onAnimationStart(animation: Animation?)
        {

        }

        override fun onAnimationRepeat(animation: Animation?)
        {
            println("repeat")
        }
        override fun onAnimationEnd(animation: Animation?) {
            var lion = MainActivity.getInstance().lion
            var cobra = MainActivity.getInstance().cobra
            var rabbit = MainActivity.getInstance().rabbit
            var enemy0 = MainActivity.getInstance().enemy0
            var moveAnim = TranslateAnimation(0f,418f,0f,418f)
            moveAnim.setAnimationListener(null)
            cobra.startAnimation(moveAnim)
            rabbit.startAnimation(moveAnim)
            lion.startAnimation(moveAnim)
            if(enemyFade)
            {
                var myFadeOut = AnimationUtils.loadAnimation(MainActivity.getInstance(), R.anim.fade_out)
                var animHandler1 = FadeOutHandler()
                myFadeOut.setAnimationListener(animHandler1)
                enemy0.startAnimation(myFadeOut)
                enemyFade = false
            }
            resetPosition()
        }

    }

    inner class DissolveHandler : Animation.AnimationListener
    {
        override fun onAnimationStart(animation: Animation?)
        {
        }
        var lion = MainActivity.getInstance().lion
        var cobra = MainActivity.getInstance().cobra
        var rabbit = MainActivity.getInstance().rabbit
        override fun onAnimationRepeat(animation: Animation?)
        {
            println("repeat")
        }
        override fun onAnimationEnd(animation: Animation?)
        {
            if(start) {
                var myFadeIn = AnimationUtils.loadAnimation(MainActivity.getInstance(), R.anim.fade_in)
                var animHandler2 = FadeInHandler()
                myFadeIn.setAnimationListener(animHandler2)
                phoneText.startAnimation(myFadeIn)
                cpuScore.startAnimation(myFadeIn)
                playerText.startAnimation(myFadeIn)
                playerScore.startAnimation(myFadeIn)
            }
        }
    }
    inner class ZoomHandler : Animation.AnimationListener
    {
        override fun onAnimationStart(animation: Animation?)
        {
        }
        override fun onAnimationRepeat(animation: Animation?)
        {
            println("repeat")
        }
        override fun onAnimationEnd(animation: Animation?)
        {
            if (!start)
            {
                var myFadeOut = AnimationUtils.loadAnimation(MainActivity.getInstance(), R.anim.fade_out)
                var animHandler1 = DissolveHandler()
                myFadeOut.setAnimationListener(animHandler1)
                titleView.startAnimation(myFadeOut)
                start = true
            }
        }
    }
    inner class FadeInHandler : Animation.AnimationListener
    {
        var result = MainActivity.getInstance().result

        override fun onAnimationStart(animation: Animation?)
        {
        }

        override fun onAnimationEnd(animation: Animation?)
        {

            if(resetLion || resetRabbit || resetCobra){
                var myFadeOut = AnimationUtils.loadAnimation(MainActivity.getInstance(), R.anim.fade_out)
                var animHandler1 = FadeOutHandler()
                myFadeOut.setAnimationListener(animHandler1)
                result.startAnimation(myFadeOut)
            }
        }
        override fun onAnimationRepeat(animation: Animation?)
        {
            println("repeat")
        }

    }


    inner class MoveHandler : Animation.AnimationListener
    {
        var lion = MainActivity.getInstance().lion
        var cobra = MainActivity.getInstance().cobra
        var rabbit = MainActivity.getInstance().rabbit
        var enemy0 = MainActivity.getInstance().enemy0
        var result = MainActivity.getInstance().result

        override fun onAnimationStart(animation: Animation?)
        {
            println("move start")
        }

        override fun onAnimationRepeat(animation: Animation?)
        {
            println("repeat")
        }
        override fun onAnimationEnd(animation: Animation?)
        {
            if (rnd == 0 && resetCobra){
                var myFadeOut = AnimationUtils.loadAnimation(MainActivity.getInstance(), R.anim.fade_out)
                var animHandler1 = FadeOutHandler()
                myFadeOut.setAnimationListener(animHandler1)
                enemy0.startAnimation(myFadeOut)
                cobraFade = true
            }
            else if (rnd == 0 && resetRabbit)
            {
                var myFadeOut = AnimationUtils.loadAnimation(MainActivity.getInstance(), R.anim.fade_out)
                var animHandler1 = FadeOutHandler()
                myFadeOut.setAnimationListener(animHandler1)
                rabbit.startAnimation(myFadeOut)
                enemyFade = true

            }
            else if(rnd == 1 && resetLion)
            {
                var myFadeOut = AnimationUtils.loadAnimation(MainActivity.getInstance(), R.anim.fade_out)
                var animHandler1 = FadeOutHandler()
                myFadeOut.setAnimationListener(animHandler1)
                lion.startAnimation(myFadeOut)
                enemyFade = true

            }
            else if(rnd == 1 && resetRabbit)
            {
                var myFadeOut = AnimationUtils.loadAnimation(MainActivity.getInstance(), R.anim.fade_out)
                var animHandler1 = FadeOutHandler()
                myFadeOut.setAnimationListener(animHandler1)
                enemy0.startAnimation(myFadeOut)
                rabbitFade = true

            }
            else if(rnd == 2 && resetCobra)
            {
                var myFadeOut = AnimationUtils.loadAnimation(MainActivity.getInstance(), R.anim.fade_out)
                var animHandler1 = FadeOutHandler()
                myFadeOut.setAnimationListener(animHandler1)
                cobra.startAnimation(myFadeOut)
                enemyFade = true
            }
            else if(rnd == 2 && resetLion)
            {
                var myFadeOut = AnimationUtils.loadAnimation(MainActivity.getInstance(), R.anim.fade_out)
                var animHandler1 = FadeOutHandler()
                myFadeOut.setAnimationListener(animHandler1)
                enemy0?.startAnimation(myFadeOut)
                lionFade = true
            }
        }
    }
}

